package com.cg.hbms.exception;

public class HbmsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HbmsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
